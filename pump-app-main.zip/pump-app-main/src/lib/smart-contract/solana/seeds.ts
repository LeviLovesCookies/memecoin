// Constants from our program
const MINT_SEED = "mmm";
const METADATA_SEED = "metadata";
const TOKEN_VAULT_SEED = "token_vault";
